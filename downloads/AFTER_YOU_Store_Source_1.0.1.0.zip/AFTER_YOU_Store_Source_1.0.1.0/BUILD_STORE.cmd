@echo off
call "%~dp0deploy\microsoft-store\BUILD_STORE.cmd" %*
