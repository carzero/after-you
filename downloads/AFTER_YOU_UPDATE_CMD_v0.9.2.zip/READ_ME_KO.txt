UPDATE.cmd를 최신 v0.9.2 Cloudflare 소스 폴더의 package.json 및 wrangler.jsonc 옆에 넣고 실행하세요.
이 작은 ZIP에는 게임 코드가 없으므로 이전 버전 폴더에 넣기만 해서는 게임이 업데이트되지 않습니다.
전체 배포 ZIP: AFTER_YOU_Cloudflare_CMD_v0.9.2.zip
Windows에서 확장자가 숨겨져 있으면 UPDATE로 보일 수 있습니다.
